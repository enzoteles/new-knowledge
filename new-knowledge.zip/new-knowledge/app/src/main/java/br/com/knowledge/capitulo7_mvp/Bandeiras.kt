package br.com.knowledge.capitulo7_mvp

class Bandeiras(var name: String, var url:String)