package br.com.knowledge.capitulo2_laoyout

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import br.com.knowledge.R

class Capitulo2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.capitulo2)
    }
}
