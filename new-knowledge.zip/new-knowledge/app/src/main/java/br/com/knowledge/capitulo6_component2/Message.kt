package br.com.knowledge.capitulo6_component2

data class Message(var msg:String)